function caseList($scope) {
    $scope.cases= [
    {client: 'Redacted', description:'This dude was charged for murder!', outcome:'Not Guilty', pic:'yes'},
    {client: 'Redacted', description:'This dude was charged for murder!', outcome:'Not Guilty', pic:'yes'},
    {client: 'Redacted', description:'This dude was charged for murder!', outcome:'Guilty', pic:'no'}
    ];
}
