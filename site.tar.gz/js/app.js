var app = angular.module("someLegalSite", []);
